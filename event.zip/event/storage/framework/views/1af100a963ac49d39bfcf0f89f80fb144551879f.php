<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style type="text/css">
		header {
			background-color: lightsalmon;
		}
		body {
			background-color: darkgray;
		}
	</style>
</head>
<body>
	<header>Welcome to Event management</header>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a href="/home" class="nav-link">Home</a>
			</li>
			<li class="nav-item">
				<a href="/register" class="nav-link">Registration</a>
			</li>
			<li class="nav-item">
				<a href="/login" class="nav-link active">Login</a>
			</li>
		</ul>
	</nav>
	<div class="container">
		<div class="row">
			<div class="col-sm-4"></div>
			<div class="col-sm-4">
				<h3>Login</h3>
				<form method="post" action="welcome_user">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label>Email</label>
						<input type="text" name="email" class="form-control">
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="pass" class="form-control">
					</div>
					<div class="form-group">
						<input type="submit" name="submit" value="Login">
					</div>
				</form>
				<?php if(session('error')): ?>
				<p style="color: red;">
					<?php echo e(session('error')); ?>

				</p>
				<?php endif; ?>
			</div>
			<div class="col-sm-4"></div>
		</div>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\event\resources\views/login.blade.php ENDPATH**/ ?>