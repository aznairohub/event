<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<h3>Welcome to event management</h3>

</body>
</html><?php /**PATH C:\xampp\htdocs\event\resources\views/event_reg.blade.php ENDPATH**/ ?>