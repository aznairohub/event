<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\event_users;

class event extends Controller
{
    public function view()
    {
        return view('home');
    }
    public function viewReg()
    {
        return view('register');
    }
    public function viewLogin()
    {
        return view('login');
    }
    public function insert(request $req)
    {
        $name = $req->input('name');
        $address = $req->input('address');
        $city = $req->input('city');
        $state = $req->input('state');
        $pin = $req->input('pin');
        $mobile = $req->input('mobile');
        $email = $req->input('email');
        $pass = $req->input('pass');
        $data = ['name'=> $name,
        'address'=> $address,
        'city'=> $city,
        'state'=> $state,
        'pincode'=> $pin,
        'mobile'=> $mobile,
        'email'=> $email,
        'password'=> $pass];
        $res = event_users::insert($data);
        return redirect('/login');
    }
   
    public function viewStatus()
    {
        return view('/status');
    }
    public function viewBooking()
    {
        return view('/book_event');
    }
    
    public function login(request $req)
    {
        $email = $req->input('email');
        $pass = $req->input('pass');
        $data = event_users::where('email',$email)->where('password',$pass)->first();
        if (isset($data)) {
            $req->session()->put(array('sess'=>$data->id));
            $req->session()->put(array('sessName'=>$data->name));
            return redirect('/welcome_user');
        } else {
            return redirect('/login')->with('error','Invalid Email or Password');
        }
    }
   
    public function viewUpdate()
    {
        $id = session('sess');
        $data['res'] = event_users::where('id',$id)->get();
        return view('/update',$data);
    }
     public function viewWelcome()
    {
        return view('welcome_user');
    }
}
