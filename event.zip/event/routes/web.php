<?php

use Illuminate\Support\Facades\Route;
use App\http\controllers\event;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
 Route::get('/home',[event::class,'view']);           //view home page
 Route::get('/register',[event::class,'viewReg']);    //view register page
 Route::get('/login',[event::class,'viewLogin']);     //view login page

 Route::post('/login',[event::class,'insert']);       //insert data into table or registration
 
 Route::get('/welcome_user',[event::class,'viewWelcome']);   //view welcome_user page
 Route::get('/status',[event::class,'viewStatus']);         //view status page
 Route::get('/book_event',[event::class,'viewBooking']);     //view book_event page
 Route::get('/update',[event::class,'viewUpdate']);         //view update page

 Route::post('/welcome_user',[event::class,'login']); //login 
 