<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
		<style type="text/css">
		header {
			background-color: lightsalmon;
		}
	</style>
</head>
<body>
	<header>Welcome to Event management</header>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
		<ul class="navbar-nav">
			<li class="nav-item">
				<a href="/status" class="nav-link active">View Status</a>
			</li>
			<li class="nav-item">
				<a href="/book_event" class="nav-link">Book Event</a>
			</li>
			<li class="nav-item">
				<a href="/update" class="nav-link">Update profile</a>
			</li>
			<li class="nav-item">
				<a href="/logout" class="nav-link">Logout</a>
			</li>
		</ul>
	</nav>
	<h3>Status</h3>

</body>
</html>